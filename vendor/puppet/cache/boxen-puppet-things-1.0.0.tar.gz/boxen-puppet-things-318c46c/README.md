# Things 2 Puppet Module for Boxen

## Usage

```puppet
include things
```

## Required Puppet Modules

* boxen

## Developing

Write code.

Run `script/cibuild`.
